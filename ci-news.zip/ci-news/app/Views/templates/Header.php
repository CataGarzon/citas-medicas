<!doctype html>
<html>
<head>
    <title>Capital Salud - Catalina Lozano</title>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('public/css/style.css'); ?>">



</head>
<body>

<section id="header">
   <center>
    <div>
      <ul id="navbar">
        <li><a href="home">Página principal</a></li>
        <li><a href="about">Citas</a></li>
        <li><a href="contact">Contacto</a></li>
        <li><a href="#">Salir</a></li>
      </ul>
    </div>
  </section>