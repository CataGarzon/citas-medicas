<!DOCTYPE html>
<html>

<head>
<center>
<title>Registro de Citas Médicas</title>
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
  </style>
</head>
<body>
  <h2>Registro de Citas Médicas</h2>

  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" required><br><br>

    <label for="fecha">Fecha:</label>
    <input type="date" id="fecha" name="fecha" required><br><br>

    <label for="hora">Hora:</label>
    <input type="time" id="hora" name="hora" required><br><br>

    <input type="submit" value="Registrar Cita">
  </form>

  <?php
  // Verificar si se ha enviado el formulario
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los valores del formulario
    $nombre = $_POST["nombre"];
    $fecha = $_POST["fecha"];
    $hora = $_POST["hora"];

    // Mostrar los datos ingresados en una tabla
    echo "<h3>Datos de la cita registrada:</h3>";
    echo "<table>";
    echo "<tr><th>Nombre</th><th>Fecha</th><th>Hora</th></tr>";
    echo "<tr><td>$nombre</td><td>$fecha</td><td>$hora</td></tr>";
    echo "</table>";
  }
  ?>
</body>
</html>

<a href="home">Volver al inicio</a>
<br>