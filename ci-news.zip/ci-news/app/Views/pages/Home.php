<center>
<section id="hero">
    <h4>¡Bienvenid@ a Capital Salud!</h4>
    <h2>Pide tu cita medica</h2>
    <h1>haciendo click aca</h1>


    <div><a class="button1" href="about">Agenda tu cita</a></div>

  </section>



  <footer class="section-p1">
    <div class="col">
    
      <h4>Contacto</h4>
      <p><strong>Ubicación:</strong> Nariño - Bogotá</p>
      <p><strong>Teléfono:</strong> +57 3194033721</p>
      <p><strong>Horas:</strong> 08:00 - 18:00, Lun - Sab</p>
    
    <div class="col">
      <h4>Mi cuenta</h4>
      <a href="login.jsp">Iniciar sesión</a>
      <a href="#">Perfil</a>
      <a href="#">Ver mis citas</a>
    </div>
    <div class="col">
      <h4>Descargar la aplicación</h4>
     

  </footer>


  <!-- hacer esto en un jsp e importarlo en los demas -->
 
  <script src="js/script.js"></script>
</body>
